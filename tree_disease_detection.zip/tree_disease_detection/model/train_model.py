from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import os

def train_model():
    train_dir = 'data/dataset/train'
    val_dir = 'data/dataset/validation'

    if not os.path.exists(train_dir) or not os.path.exists(val_dir):
        print("⚠️ يرجى التأكد من وجود مجلدات البيانات train و validation داخل data/dataset/")
        return

    datagen = ImageDataGenerator(rescale=1./255)
    train_data = datagen.flow_from_directory(train_dir, target_size=(128, 128), batch_size=32, class_mode='categorical')
    val_data = datagen.flow_from_directory(val_dir, target_size=(128, 128), batch_size=32, class_mode='categorical')

    model = Sequential([
        Conv2D(32, (3,3), activation='relu', input_shape=(128,128,3)),
        MaxPooling2D(2,2),
        Conv2D(64, (3,3), activation='relu'),
        MaxPooling2D(2,2),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(train_data.num_classes, activation='softmax')
    ])

    model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])
    model.fit(train_data, validation_data=val_data, epochs=10)
    model.save('model/model.h5')
    print("✅ تم حفظ النموذج بنجاح في model/model.h5")

if __name__ == '__main__':
    train_model() 
