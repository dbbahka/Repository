import streamlit as st
from datetime import datetime
import os
from db_config import create_connection
from inference import predict_image

st.set_page_config(page_title="نظام فحص أمراض الأشجار الذكي 🌿", layout="centered")

st.title("🌿 نظام فحص أمراض الأشجار الذكي")
st.write("قم برفع صورة ورقة الشجرة ليتعرف النظام على حالتها باستخدام الذكاء الاصطناعي 🤖")

uploaded_file = st.file_uploader("📸 اختر صورة...", type=["jpg", "jpeg", "png"])

if uploaded_file:
    image_path = os.path.join("uploads", uploaded_file.name)
    os.makedirs("uploads", exist_ok=True)
    with open(image_path, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.image(image_path, caption="الصورة التي تم رفعها", use_column_width=True)
    st.write("🔍 جاري الفحص...")

    prediction, confidence = predict_image(image_path)
    st.success(f"✅ النتيجة: {prediction} بنسبة ثقة {confidence:.2f}%")

    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO diagnosis (image_path, prediction, confidence, date) VALUES (?, ?, ?, ?)",
                   (image_path, prediction, confidence, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
    conn.commit()
    conn.close()
    st.info("💾 تم حفظ النتيجة في قاعدة البيانات.") 
