import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image

model = tf.keras.models.load_model('model/model.h5')

def predict_image(img_path):
    img = image.load_img(img_path, target_size=(128,128))
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0

    predictions = model.predict(img_array)
    class_idx = np.argmax(predictions)
    confidence = np.max(predictions) * 100

    labels = ['سليمة', 'صدأ', 'لفحة', 'عفن']  # يمكنك تعديل الأسماء حسب بياناتك
    result = labels[class_idx]
    return result, confidence 
