import sqlite3

def create_connection():
    conn = sqlite3.connect('tree_disease.db')
    return conn

def create_table():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS diagnosis (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        image_path TEXT,
                        prediction TEXT,
                        confidence REAL,
                        date TEXT
                    )''')
    conn.commit()
    conn.close()

if __name__ == '__main__':
    create_table() 
